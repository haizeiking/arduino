Maxbotix
========
An Arduino library to read Maxbotix ultrasonic sensors. https://github.com/Diaoul/arduino-Maxbotix

History
=======
0.1
---

* Initial version

About
=====
Author: Antoine Bertin

License: MIT

Code formated with: ``astyle --break-blocks --remove-brackets``
